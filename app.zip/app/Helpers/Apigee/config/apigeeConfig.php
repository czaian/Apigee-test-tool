<?php
return [
    'from' => [
        'url' => 'http://34.55.190.84:8080',
        'serverName' => 'DEV',
        'userid' => 'opdk@apigee.com',
        'passwd' => 'Apigee123!',
        'org' => 'playground',
        'env' => 'dev'
    ],
    'to' => [
        'url' => 'http://34.55.190.84:8080',
        'userid' => 'opdk@apigee.com',
        'passwd' => 'Apigee123!',
        'org' => 'rega',
        'env' => 'dev'
    ]
];
